export const StudentSideNavBarData = [
  {
    title: "DashBoard",
    //icon: <AddBoxIcon />,
    link: "student/dashboard",
  },
  {
    title: "MyProfile",
    //icon: <DashboardIcon />,
    link: "student/myprofile",
  },
  {
    title: "Edit Profile",
    //icon: <AddBoxIcon />,
    link: "student/editprofile",
  },
];
