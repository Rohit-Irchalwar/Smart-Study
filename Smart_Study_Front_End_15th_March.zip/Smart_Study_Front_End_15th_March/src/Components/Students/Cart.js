import React from 'react'
import Navigationbar from "./Navigationbar";
export default function Cart() {
  return (
    <>
    <Navigationbar/>
    <div>
      Cart
    </div>
    </>
  )
}
