package com.sou.SmartStudy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartStudyApplicationTests {

	@Test
	void contextLoads() {
	}

}
